Online Food Ordering and Table Reservation

Technologies

HTML & CSS
Bootstrap
JavaScript & Jquery
Ajax
PHP & MYSQL

Website DEMO

https://www.youtube.com/watch?v=K5KtjIR-9ts&ab_channel=IdrissJairi

Admin Login Page: http://localhost/vincent/admin/

Installation

Download the files + database file (.sql)
Create new database with the name "restaurant_website" and then Import the SQL file downloaded
Check the files connect.php to make sure that everything is working
The website is ready to use
Feel free to edit the missing parts or the existing parts
